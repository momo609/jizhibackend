package com.jizhitest.service;

import java.util.List;

import com.jizhibackend.bean.Gift;

public class GiftDaoImpl extends BaseDaoImpl{
	private  String getGiftStmt = "com.jizhitest.mapping.giftMapping.getGift";
	private  String getGiftByIdStmt = "com.jizhitest.mapping.giftMapping.getGiftByID";
    public List<Gift> getGift()
    {
		return session.selectList(getGiftStmt);
    }
    public Gift getGiftById(int giftid)
    {
		return session.selectOne(getGiftByIdStmt, giftid);
    }
}
