package com.jizhitest.service;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import test.mybatistest;

import com.jizhibackend.bean.MyClass;
import com.jizhibackend.bean.MyTest;
import com.jizhibackend.bean.Question;
import com.jizhibackend.bean.User;
import com.jizhitest.db.DBConn;

public class MyTestDaoImpl extends BaseDaoImpl{
	
	private  String getTestOfClassStmt = "com.jizhitest.mapping.mytestMapping.getTestOfClass";
	private  String deleteTestStmt = "com.jizhitest.mapping.mytestMapping.deleteTestById";
	private  String getTestByIdStmt = "com.jizhitest.mapping.mytestMapping.getTestById";
	public List<MyTest> getTestsOfUsers(User user)
	{
		 List<MyTest> testList=new ArrayList<MyTest>();
		MyClassDaoImpl daoImpl=new MyClassDaoImpl();
		
			List<MyClass> classlist=daoImpl.ClassofStudent(user.getUserid());
			for(MyClass cls:classlist)
			{
				List<MyTest> tlist=getTestsOfClass(cls.getId());
				for(MyTest test:tlist)
				{
					test.setMyclass(cls);
				}
				testList.addAll(tlist);
			}
			
		/*else if(user.getUsertype()==User.teacher)
		{
			List<MyClass> classlist=daoImpl.ClassofOwner(user.getUserid());
			for(MyClass cls:classlist)
			{
				
				List<MyTest> tlist=getTestsOfClass(cls.getId());
				for(MyTest test:tlist)
				{
					test.setMyclass(cls);
				}
				testList.addAll(tlist);
			}
		}*/
		
		return testList;
		
	}
	public List<MyTest> getTestsOfClass(int classid)
	{
		List<MyTest> list=session.selectList(getTestOfClassStmt,classid);
		return list;
		
	}
	public static int scoreTest(int testid,String answer)
	{
		int score=0;
		MyTestDaoImpl myTestDaoImpl=new MyTestDaoImpl();
		MyTest t=myTestDaoImpl.getTestByid(testid);
		int paperid=t.getUse_paperid();
		QuestionDaoImpl questionDaoImpl=new QuestionDaoImpl();
		List<Question> qlist=questionDaoImpl.getQustionsOfTestPaper(paperid);
		String[] answers=answer.split("@@");
		for(int i=0;i<qlist.size();i++)
		{
			if(qlist.get(i).getAnswer().equals(answers[i]))
			{
				score+=qlist.get(i).getPoint();
			}
		}
	
		return score;
		
	}
	public MyTest getTestByid(int testid)
	{
		MyTest mytest=session.selectOne(getTestByIdStmt,testid);
		return mytest;
		
	}

	public boolean createTest(MyTest mytest)
	{
	
		int i=0;
		try {
			String sql="insert into test(title,start_time,end_time,create_time,owner,use_paperid,id,privilege) values(?,?,?,?,?,?,?,?)";
		    Connection conn=DBConn.getConnection();		   
		    PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, mytest.getTitle());
			ps.setLong(2, mytest.getStart_time());
			ps.setLong(3, mytest.getEnd_time());
			ps.setLong(4, mytest.getCreate_time());
			ps.setInt(5, mytest.getOwner());	
			ps.setInt(6, mytest.getUse_paperid());
			ps.setInt(7, mytest.getTestid());
			ps.setInt(8, mytest.getPrivilege());
			i=ps.executeUpdate();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		if(i==0)
			return false;
		else return true;
	
	}
	
	public boolean setTakePartInClass(MyTest mytest,int classid)
	{
	
		int i=0;
	    
		try {
			String sql="insert into r_class_test(classid,testid) values(?,?)";
		    Connection conn=DBConn.getConnection();		   
		    PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, classid);
			ps.setInt(2, mytest.getTestid());
			i=ps.executeUpdate();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		if(i==0)
			return false;
		else return true;
	
	}
	public int deleteTestById(int testid)
	{
		int i=session.delete(deleteTestStmt,testid);
		session.commit();
		return i;
		
	}

}
